ASME DETC requires Type 1 fonts for the Postscript (PS) to
Portable Document Format (PDF) conversion.  The default LaTeX
computer modern fonts are Type 3 fonts, which are bit-mapped.
Bit-mapped fonts in PDF are grainy and hard to read.

Therefore, the asme2e class uses Postscript Type 1 fonts.
The times, mathptm, and pifont packages are part of LaTeX2e
New Font Selection Scheme for PostScript fonts (PSNFSS).

You can obtain PSFNSS and the Type 1 font descriptions and font
metrics from CTAN:

    http://tug2.cs.umb.edu/ctan/tex-archive/macros/latex/packages/psnfss/
    http://tug2.cs.umb.edu/ctan/tex-archive/fonts/psfonts/

If the PSFNSS distribution is too large, download just the

    http://tug2.cs.umb.edu/ctan/tex-archive/macros/latex/packages/psnfss/psfonts.ins
    http://tug2.cs.umb.edu/ctan/tex-archive/macros/latex/packages/psnfss/psfonts.dtx

files and run

    % tex psfonts.ins

to create the times, mathptm and pifont packages.

The associated fonts you can download for these packages are in

    http://tug2.cs.umb.edu/ctan/tex-archive/fonts/psfonts/adobe/times/
    http://tug2.cs.umb.edu/ctan/tex-archive/fonts/psfonts/adobe/helvetic/
    http://tug2.cs.umb.edu/ctan/tex-archive/fonts/psfonts/adobe/courier/
    http://tug2.cs.umb.edu/ctan/tex-archive/fonts/psfonts/adobe/zapfding/

